<?php

// fichier: UserModel.php

class UserModel {
    // Propriétés
    private $dbConnection;

    // Constructeur
    public function __construct($dbConnection) {
        $this->dbConnection = $dbConnection;
    }

    // Méthode pour récupérer un utilisateur par son ID
    public function getUserById($userId) {
        // Exemple simplifié : requête SQL pour récupérer un utilisateur depuis une base de données
        $query = "SELECT * FROM users WHERE id = :userId";
        $statement = $this->dbConnection->prepare($query);
        $statement->bindParam(':userId', $userId);
        $statement->execute();
        return $statement->fetch(PDO::FETCH_ASSOC);
    }

    // Méthode pour enregistrer un nouvel utilisateur
    public function saveUser($userData) {
        // Exemple simplifié : requête SQL pour insérer un nouvel utilisateur dans la base de données
        $query = "INSERT INTO users (username, email, password) VALUES (:username, :email, :password)";
        $statement = $this->dbConnection->prepare($query);
        $statement->bindParam(':username', $userData['username']);
        $statement->bindParam(':email', $userData['email']);
        $statement->bindParam(':password', $userData['password']);
        return $statement->execute();
    }

    // Autres méthodes pour la gestion des utilisateurs...
}
?>
